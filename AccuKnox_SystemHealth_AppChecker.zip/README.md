# 🧾 AccuKnox QA Trainee – Python Automation Scripts

This repository contains two Python scripts developed as part of the **AccuKnox QA Trainee Assessment**.

---

## 🎯 Objective 1: System Health Monitoring Script
- Monitors **CPU, Memory, and Disk usage**
- Logs alerts when any metric exceeds defined thresholds
- Saves data to `system_health.log`

### Run Command
```bash
python system_health_monitor.py
```

---

## 🎯 Objective 2: Application Health Checker Script
- Checks uptime of web applications by verifying **HTTP status codes**
- Logs the result (`UP` / `DOWN`) to `app_health.log`
- Works with multiple URLs

### Run Command
```bash
python app_health_checker.py
```

---

## ⚙️ Requirements
- Python 3.8+
- Install dependencies:
```bash
pip install -r requirements.txt
```

---

## 🧩 Python Libraries Used
- psutil
- requests

---

## 👩‍💻 Author
**Kavya Kannan**  
GitHub: [@kavyakannan58](https://github.com/kavyakannan58)

---
