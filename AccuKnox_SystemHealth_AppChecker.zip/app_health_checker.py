import requests
import datetime

URLS = [
    "https://opensource-demo.orangehrmlive.com/",
    "https://www.google.com/"
]

LOG_FILE = "app_health.log"

def log_status(url, status):
    with open(LOG_FILE, "a") as f:
        f.write(f"{datetime.datetime.now()} - {url} - {status}\n")

def check_app_health():
    for url in URLS:
        try:
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                print(f"{url} ✅ UP")
                log_status(url, "UP")
            else:
                print(f"{url} ❌ DOWN (HTTP {response.status_code})")
                log_status(url, f"DOWN (HTTP {response.status_code})")
        except requests.exceptions.RequestException:
            print(f"{url} ❌ DOWN (No Response)")
            log_status(url, "DOWN (No Response)")

if __name__ == "__main__":
    check_app_health()
