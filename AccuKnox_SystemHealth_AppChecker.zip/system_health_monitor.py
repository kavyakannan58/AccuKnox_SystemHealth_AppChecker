import psutil
import datetime

CPU_THRESHOLD = 80
MEM_THRESHOLD = 80
DISK_THRESHOLD = 90
LOG_FILE = "system_health.log"

def log_message(message):
    with open(LOG_FILE, "a") as f:
        f.write(f"{datetime.datetime.now()} - {message}\n")

def check_system_health():
    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent

    log_message(f"CPU: {cpu}%, Memory: {mem}%, Disk: {disk}%")

    if cpu > CPU_THRESHOLD:
        log_message("⚠️ ALERT: CPU usage exceeded threshold!")
    if mem > MEM_THRESHOLD:
        log_message("⚠️ ALERT: Memory usage exceeded threshold!")
    if disk > DISK_THRESHOLD:
        log_message("⚠️ ALERT: Disk space exceeded threshold!")

    print(f"CPU: {cpu}%, Memory: {mem}%, Disk: {disk}% - Check log for details.")

if __name__ == "__main__":
    check_system_health()
